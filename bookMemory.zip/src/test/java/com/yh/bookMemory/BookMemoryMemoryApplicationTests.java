package com.yh.bookMemory;

import com.yh.bookMemory.repository.BookSentencesRepository;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookMemoryMemoryApplicationTests {





}
