package com.yh.bookMemory;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BookMemoryApplication {

	public static void main(String[] args) {
		SpringApplication.run(BookMemoryApplication.class, args);
	}

}
